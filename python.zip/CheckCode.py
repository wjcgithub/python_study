# -*- coding: utf-8 -*-
from hashlib import md5
import base64
import requests

image_path = './CheckCode.png'     # 存放验证码图片地址
url = 'http://www.seemmark.com/external-api/external/captcha/v3'
key = 'd77e8104d61d4b98958fb70464dc3097'    # 用户专属key
user_id = '59a8bf35dfad8b32719167eb'

class CheckCode(object):
    """docstring for CheckCode"""
    # def __init__(self, arg):
    #     super(CheckCode, self).__init__()
    #     self.arg = arg
        
    def signature(args, key):
        message = ''
        message = '&'.join(['='.join([key,str(item)]) for key,item in sorted(args.items())])
        message = '&'.join([message, key])
        return md5(message.encode('utf-8')).hexdigest()


    def do_test(args):
        data = {
            'codeID': 1003,
            # 'length': 4,
            'userId': user_id,
        }
        image_file = open(image_path, 'rb')
        data['image'] = base64.b64encode(image_file.read()) #读取图片用base64进行编码
        # print(data)
        data['sign'] = CheckCode.signature(data, key)
        resp = requests.post(url, data=data)
        print(resp.content)
        image_file.close()